"""Classification utilities for 3D-BrAIn/MEA spike data.

This module contains reusable helpers for supervised classification workflows.
It supports two main use cases:

1. classification from already extracted feature vectors stored in pickle files;
2. classification directly from raw spike waveforms/time series using MiniRocket
   followed by a ridge classifier.

MiniRocket inputs are treated as panels of time series. A 2D array is interpreted
as ``(samples, timepoints)`` and internally reshaped to
``(samples, 1, timepoints)``. A 3D array is interpreted as
``(samples, channels, timepoints)``.

The functions here are intentionally independent from a specific experiment
layout. Main scripts are responsible for deciding whether samples are split by
recording, organoid, experimental date, or another biological grouping.
"""

import json
import os
import re
import tempfile
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression, RidgeClassifierCV as SklearnRidgeClassifierCV
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from . import Mamba, SpikeSorting

try:
    from sktime.transformations.panel.rocket import MiniRocket, MiniRocketMultivariate
except ImportError:
    MiniRocket = None
    MiniRocketMultivariate = None


def RecordingKey(Value):
    """Normalize a recording identifier for table joins."""
    if pd.isna(Value):
        return ""
    Text = re.sub(r"\.brw$", "", str(Value).strip(), flags=re.IGNORECASE)
    return re.sub(r"\s+", "", Text).lower()


def SafeName(Value):
    """Convert a value into a filesystem-safe identifier."""
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(Value)).strip("_")


def FindWellMetricFiles(MetricsRoot):
    """Find well-level spike and burst metric tables below a root."""
    return sorted(Path(MetricsRoot).glob("**/spike_burst/well_spike_burst_metrics.csv"))


def LoadWellMetrics(MetricsRoots):
    """Load and concatenate well-level metrics from multiple roots."""
    Rows = []
    CheckedRoots = []
    for MetricsRoot in map(Path, MetricsRoots):
        CheckedRoots.append(str(MetricsRoot))
        if not MetricsRoot.exists():
            continue
        for MetricPath in FindWellMetricFiles(MetricsRoot):
            Metric = pd.read_csv(MetricPath)
            if Metric.empty:
                continue
            First = Metric.iloc[0].copy()
            RecordingName = First.get("RecordingName", MetricPath.parents[1].name)
            First["recording_name"] = RecordingName
            First["recording_name_key"] = RecordingKey(RecordingName)
            First["metrics_path"] = str(MetricPath)
            Rows.append(First)
    if not Rows:
        raise FileNotFoundError(
            "No well_spike_burst_metrics.csv files found under: "
            + ", ".join(CheckedRoots)
        )
    return pd.DataFrame(Rows)


def LoadChannelMetrics(LabeledWell):
    """Load channel metrics associated with labeled well records."""
    Rows = []
    for _, Row in LabeledWell.iterrows():
        ChannelPath = Path(Row["metrics_path"]).with_name("channel_spike_burst_metrics.csv")
        if not ChannelPath.exists():
            continue
        Channels = pd.read_csv(ChannelPath)
        Channels.insert(0, "record_id", Row["record_id"])
        Channels.insert(1, "recording_name", Row["recording_name"])
        Channels.insert(2, "label_normalized", Row["label_normalized"])
        Channels.insert(3, "label_code", Row["label_code"])
        Rows.append(Channels)
    return pd.concat(Rows, ignore_index=True) if Rows else pd.DataFrame()


def FeatureColumns(Frame, NonFeatureColumns):
    """Select numeric analysis features while excluding metadata columns."""
    Numeric = Frame.select_dtypes(include=[np.number, "bool"]).columns.tolist()
    return [
        Column for Column in Numeric
        if Column not in NonFeatureColumns
        and not Column.endswith("_present")
        and Column not in {"combination_present", "spontaneous_control"}
    ]


def LoadRecordingWaveforms(
    RecordingDirectory,
    RandomGenerator,
    FilterConfig,
    RecordingDuration,
    MinimumActiveRate,
    MaximumSpikes,
    ExcludeChannel=None,
):
    """Load and summarize waveforms selected by a polarity configuration."""
    ActiveWaveforms, ActiveCounts = [], []
    InputCount = LabelCount = FilteredCount = ChannelsWithSpikes = 0
    for Channel, Arrays in SpikeSorting.LoadSpikeRecording(RecordingDirectory).items():
        if ExcludeChannel is not None and Channel == ExcludeChannel:
            continue
        Spikes = Arrays["Spikes"]
        if Spikes.size == 0:
            continue
        Spikes = np.asarray(Spikes).reshape(Spikes.shape[0], -1)
        Labels = Arrays["Labels"]
        Count = min(len(Spikes), len(Labels))
        Spikes, Labels = Spikes[:Count], Labels[:Count]
        InputCount += Count
        Polarity = getattr(FilterConfig, "polarity", "negative")
        LabelOnlyConfig = SpikeSorting.SpikePolarityFilterConfig(
            polarity=Polarity,
            negative_spike_label=FilterConfig.negative_spike_label,
            positive_spike_label=getattr(FilterConfig, "positive_spike_label", 1),
            use_detector_label_filter=FilterConfig.use_detector_label_filter,
            use_waveform_polarity_filter=False,
        )
        LabelCount += int(SpikeSorting.WaveformPolarityMask(Spikes, Labels, LabelOnlyConfig).sum())
        if isinstance(FilterConfig, SpikeSorting.NegativeSpikeFilterConfig):
            Keep = SpikeSorting.NegativeWaveformMask(Spikes, Labels, FilterConfig)
        else:
            Keep = SpikeSorting.WaveformPolarityMask(Spikes, Labels, FilterConfig)
        FilteredCount += int(Keep.sum())
        Spikes = Spikes[Keep]
        if not len(Spikes):
            continue
        ChannelsWithSpikes += 1
        if len(Spikes) / float(RecordingDuration) <= MinimumActiveRate:
            continue
        ActiveWaveforms.append(Spikes)
        ActiveCounts.append(len(Spikes))
    if not ActiveWaveforms:
        raise ValueError(f"No active plausible {getattr(FilterConfig, 'polarity', 'negative')}-spike channels found.")
    Waveforms = np.vstack(ActiveWaveforms)
    if len(Waveforms) > MaximumSpikes:
        Waveforms = Waveforms[RandomGenerator.choice(len(Waveforms), MaximumSpikes, replace=False)]
    Counts = np.asarray(ActiveCounts, dtype=float)
    Total = float(Counts.sum())
    Probabilities = Counts / Total if Total else np.zeros_like(Counts)
    Metadata = {
        "recording_name": Path(RecordingDirectory).name,
        "n_input_spikes": InputCount,
        "n_after_label_filter": LabelCount,
        "n_after_waveform_filter": FilteredCount,
        "total_spikes": Total,
        "sampled_spikes": len(Waveforms),
        "duration_seconds": float(RecordingDuration),
        "firing_rate_hz": Total / float(RecordingDuration),
        "n_channels_with_spikes": ChannelsWithSpikes,
        "n_active_channels": len(Counts),
        "mean_spikes_per_channel": float(np.mean(Counts)),
        "median_spikes_per_channel": float(np.median(Counts)),
        "max_spikes_per_channel": float(np.max(Counts)),
        "channel_entropy": float(-(Probabilities * np.log2(Probabilities + 1e-12)).sum()),
        "waveform_mean": float(np.mean(Waveforms)),
        "waveform_std": float(np.std(Waveforms)),
        "waveform_min": float(np.min(Waveforms)),
        "waveform_max": float(np.max(Waveforms)),
        "waveform_ptp": float(np.ptp(Waveforms)),
        "waveform_energy": float(np.mean(Waveforms ** 2)),
    }
    return Waveforms.astype(np.float32), Metadata


def LoadNegativeRecordingWaveforms(
    RecordingDirectory,
    RandomGenerator,
    FilterConfig,
    RecordingDuration,
    MinimumActiveRate,
    MaximumSpikes,
    ExcludeChannel=None,
):
    """Load negative recording waveforms through the legacy public interface."""
    return LoadRecordingWaveforms(
        RecordingDirectory,
        RandomGenerator,
        FilterConfig,
        RecordingDuration,
        MinimumActiveRate,
        MaximumSpikes,
        ExcludeChannel,
    )


def MambaSequence(Waveforms):
    """Build the five-profile sequence used by recording-level Mamba models."""
    return np.stack([
        np.mean(Waveforms, axis=0), np.std(Waveforms, axis=0),
        np.median(Waveforms, axis=0), np.percentile(Waveforms, 25, axis=0),
        np.percentile(Waveforms, 75, axis=0),
    ]).astype(np.float32)


def ClassicalFeatureRow(Metadata, Waveforms, Bundle):
    """Build one recording-level feature row for a saved classical model."""
    Values = {Key: float(Value) for Key, Value in Metadata.items() if isinstance(Value, (int, float))}
    Extractor = Bundle.get("rocket_extractor")
    if Extractor is not None:
        Features = np.asarray(Extractor.transform(Waveforms[:, np.newaxis, :]))
        Values.update({f"rocket_mean_{Index}": Value for Index, Value in enumerate(Features.mean(axis=0))})
        Values.update({f"rocket_std_{Index}": Value for Index, Value in enumerate(Features.std(axis=0))})
    Row = pd.DataFrame([{Column: Values.get(Column, 0.0) for Column in Bundle["feature_columns"]}])
    return Row.replace([np.inf, -np.inf], np.nan).fillna(0)


def LabelFromMapping(Mapping, Code):
    """Resolve a predicted code to its stored display label."""
    for Key in (Code, int(Code) if isinstance(Code, np.integer) else Code, str(Code)):
        if Key in Mapping:
            return Mapping[Key]
    return str(Code)


def ParseModelName(ModelName):
    """Split a composite model name into feature-set and classifier names."""
    for FeatureSet in ("activity", "waveform", "combined"):
        Prefix = f"{FeatureSet}_"
        if ModelName.startswith(Prefix):
            return FeatureSet, ModelName[len(Prefix):]
    return None, ModelName


def BuildRecordingFeatureMatrix(Recordings, Names, Waveforms, Extractor, Columns, BaseColumns):
    """Aggregate scalar and optional ROCKET features by recording."""
    Rows = []
    for _, Recording in Recordings.set_index("recording_name").loc[Names].reset_index().iterrows():
        Values = {Column: float(Recording[Column]) for Column in BaseColumns}
        if Extractor is not None:
            Features = np.asarray(Extractor.transform(Waveforms[Recording["recording_name"]][:, np.newaxis, :]))
            Values.update({f"rocket_mean_{Index}": Value for Index, Value in enumerate(Features.mean(axis=0))})
            Values.update({f"rocket_std_{Index}": Value for Index, Value in enumerate(Features.std(axis=0))})
        Rows.append(pd.Series(Values, name=Recording["recording_name"]))
    Matrix = pd.DataFrame(Rows)
    Matrix.index.name = "recording_name"
    return Matrix.reindex(columns=Columns).replace([np.inf, -np.inf], np.nan).fillna(0)


def ToJsonable(Value):
    """Convert NumPy, path, and nested values into JSON-compatible data."""
    if isinstance(Value, dict):
        return {str(Key): ToJsonable(Item) for Key, Item in Value.items()}
    if isinstance(Value, (list, tuple)):
        return [ToJsonable(Item) for Item in Value]
    if isinstance(Value, np.ndarray):
        return ToJsonable(Value.tolist())
    if isinstance(Value, np.integer):
        return int(Value)
    if isinstance(Value, np.floating):
        return float(Value)
    if isinstance(Value, np.bool_):
        return bool(Value)
    if isinstance(Value, Path):
        return str(Value)
    if Value is None or isinstance(Value, (str, int, float, bool)):
        return Value
    return str(Value)


def SaveJson(PathValue, Payload):
    """Serialize a metadata payload as deterministic indented JSON."""
    with open(PathValue, "w", encoding="utf-8") as Handle:
        json.dump(ToJsonable(Payload), Handle, indent=2, sort_keys=True)


def ModelFamily(ClassifierName):
    """Return the broad algorithm family for a classifier name."""
    if ClassifierName == "mamba": return "State-space model"
    if "svm" in ClassifierName: return "SVM"
    if "forest" in ClassifierName or "trees" in ClassifierName: return "Ensemble"
    if "logistic" in ClassifierName or "ridge" in ClassifierName: return "Linear model"
    if "dummy" in ClassifierName: return "Baseline"
    return "Machine learning"


def ModelTypeLabel(ClassifierName):
    """Return a human-readable model type for catalogue metadata."""
    Labels = {
        "mamba": "Selective state-space sequence model", "ridge_pca90": "Ridge classifier with PCA",
        "logistic_balanced_pca90": "Balanced logistic regression with PCA",
        "linear_svm_balanced_pca90": "Balanced linear support vector machine with PCA",
        "rbf_svm_balanced_pca90": "Balanced RBF support vector machine with PCA",
        "random_forest_balanced": "Balanced random forest classifier",
        "extra_trees_balanced": "Balanced Extra Trees classifier",
        "dummy_most_frequent": "Most-frequent-class dummy baseline",
    }
    return Labels.get(ClassifierName, ClassifierName.replace("_", " "))


def BuildRecordingClassifiers(PcaVariance=0.90, RandomState=42):
    """Construct fresh baseline, linear, kernel, and tree classifiers."""
    return {
        "dummy_most_frequent": make_pipeline(DummyClassifier(strategy="most_frequent")),
        "ridge_pca90": make_pipeline(StandardScaler(), PCA(n_components=PcaVariance, svd_solver="full"), SklearnRidgeClassifierCV(alphas=np.logspace(-3, 3, 10))),
        "logistic_balanced_pca90": make_pipeline(StandardScaler(), PCA(n_components=PcaVariance, svd_solver="full"), LogisticRegression(class_weight="balanced", max_iter=5000)),
        "linear_svm_balanced_pca90": make_pipeline(StandardScaler(), PCA(n_components=PcaVariance, svd_solver="full"), SVC(kernel="linear", class_weight="balanced")),
        "rbf_svm_balanced_pca90": make_pipeline(StandardScaler(), PCA(n_components=PcaVariance, svd_solver="full"), SVC(kernel="rbf", class_weight="balanced")),
        "random_forest_balanced": make_pipeline(RandomForestClassifier(n_estimators=300, class_weight="balanced", max_features="sqrt", random_state=RandomState, n_jobs=-1)),
        "extra_trees_balanced": make_pipeline(ExtraTreesClassifier(n_estimators=300, class_weight="balanced", max_features="sqrt", random_state=RandomState, n_jobs=-1)),
    }


def TrainingDatasetMetadata(Recordings, SelectedModels, Context):
    """Build serializable metadata describing a recording-level training set."""
    Group = Context["group_column"]
    Counts = Recordings.groupby(["label_code", "label_normalized"], as_index=False).agg(
        recordings=("recording_name", "count"), biological_units=(Group, "nunique"),
        sampled_spikes=("sampled_spikes", "sum"), active_channels=("n_active_channels", "sum"),
    ).sort_values("label_code")
    return {
        "experiment_id": Context["experiment_id"], "experiment_name": Context["experiment_name"],
        "target_name": Context["target_name"], "target_column": Context["target_column"],
        "target_label_column": Context["target_label_column"], "group_column": Group,
        "sample_unit": "recording", "split_unit": Group,
        "polarity_scope": Context["spike_polarity_filter"]["polarity"],
        "n_recordings": len(Recordings), "n_biological_units": Recordings[Group].nunique(),
        "n_classes": Recordings["label_code"].nunique(),
        "total_input_spikes": Recordings["n_input_spikes"].sum(),
        "total_detector_selected_spikes": Recordings["n_after_label_filter"].sum(),
        "total_plausible_selected_spikes": Recordings["n_after_waveform_filter"].sum(),
        "total_training_sampled_spikes": Recordings["sampled_spikes"].sum(),
        "class_mapping": {str(Key): str(Value) for Key, Value in Context["name_by_code"].items()},
        "class_distribution": Counts.to_dict("records"), "selected_final_models": SelectedModels,
        "feature_sets": Context["feature_sets"], "training_parameters": Context["training_parameters"],
        "spike_polarity_filter": Context["spike_polarity_filter"],
        "mamba_parameters": Context["mamba_parameters"],
    }


def ModelMetrics(ModelName, Metrics, Comparison):
    """Collect cross-validation summary and fold metrics for one model."""
    Summary = Comparison.set_index("model").loc[ModelName].to_dict()
    return {"rank": int(Summary.get("rank", 0)), "cv_summary": Summary,
            "cv_folds": Metrics[Metrics["model"] == ModelName].to_dict("records"),
            "training_metrics": {"mean_cv_train_accuracy": Summary.get("mean_train_accuracy"), "mean_cv_train_balanced_accuracy": Summary.get("mean_train_balanced_accuracy")},
            "test_metrics": {"mean_cv_test_accuracy": Summary.get("mean_test_accuracy"), "std_cv_test_accuracy": Summary.get("std_test_accuracy"), "mean_cv_test_balanced_accuracy": Summary.get("mean_test_balanced_accuracy"), "std_cv_test_balanced_accuracy": Summary.get("std_test_balanced_accuracy"), "n_cv_folds": Summary.get("n_folds")}}


def RecordingManifest(Recordings, GroupColumn, TargetLabelColumn):
    """Build the manifest of recordings used for final model training."""
    Columns = ["recording_name", GroupColumn, TargetLabelColumn, "label_code", "label_normalized", "protocol", "div", "sampled_spikes", "n_active_channels", "firing_rate_hz"]
    return Recordings[[Column for Column in Columns if Column in Recordings.columns]].to_dict("records")


def ModelMetadata(ModelName, ModelType, ModelPath, FeatureSet, ClassifierName, FeatureColumns, EstimatorParameters, Recordings, Metrics, Comparison, Context):
    """Build reusable-model metadata for a fitted classification model."""
    return {
        "model_id": ModelName, "model_name": ModelName, "model_type": ModelType,
        "classifier": ClassifierName, "classifier_family": ModelFamily(ClassifierName),
        "classifier_description": ModelTypeLabel(ClassifierName),
        "framework": "PyTorch" if ModelType == "torch_state_dict" else "scikit-learn",
        "model_path": str(ModelPath), "created_by_main": Context["created_by_main"],
        "dataset": TrainingDatasetMetadata(Recordings, [ModelName], Context),
        "training_recordings": RecordingManifest(Recordings, Context["group_column"], Context["target_label_column"]),
        "feature_set": FeatureSet, "feature_columns": FeatureColumns, "n_features": len(FeatureColumns),
        "estimator_parameters": EstimatorParameters, "preprocessing": Context["preprocessing"],
        "validation": Context["validation"], "metrics": ModelMetrics(ModelName, Metrics, Comparison),
        "reuse_notes": "Final reusable model fitted on all available labelled recordings after cross-validation. Reported test metrics are cross-validated held-out-fold metrics.",
    }


def PortalCatalogRecord(Metadata, ExperimentId, TargetName, GroupColumn):
    """Convert model metadata into the external portal catalogue schema."""
    Test = Metadata["metrics"]["test_metrics"]
    return {"id": Metadata["model_id"], "name": Metadata["classifier_description"],
            "version": f"Experiment {ExperimentId} research model", "status": "Research",
            "classificationFamily": Metadata["classifier_family"], "modelType": Metadata["classifier_description"],
            "purpose": f"Recording-level classification of {TargetName.replace('_', ' ')} from plausible negative MEA spikes.",
            "framework": Metadata["framework"], "input": f"{Metadata['feature_set']} features extracted from processed spike folders",
            "output": "Predicted experimental class with class probabilities when supported",
            "validation": f"Repeated group-disjoint cross-validation by {GroupColumn}",
            "metrics": [f"Balanced accuracy: {Test['mean_cv_test_balanced_accuracy']:.3f}", f"Accuracy: {Test['mean_cv_test_accuracy']:.3f}", f"CV folds: {int(Test['n_cv_folds'])}"],
            "owner": "University of Genoa", "workPackage": "WP3", "license": "MIT", "access": "Restricted",
            "repository": "https://github.com/cristinacampi/3D-BrAIn_codes", "downloadUrl": None,
            "keywords": ["MEA", "classification", TargetName, Metadata["feature_set"], Metadata["classifier_family"]],
            "limitations": "Research use only; no independent external validation."}


def PredictClassicalRecordings(ModelPath, RecordingDirectories, LoaderArguments, RandomState=42):
    """Apply a saved scikit-learn classifier bundle to recordings."""
    Bundle = joblib.load(ModelPath)
    Generator = np.random.default_rng(RandomState)
    Rows = []
    for Directory in RecordingDirectories:
        Waveforms, Metadata = LoadRecordingWaveforms(Directory, Generator, **LoaderArguments)
        Features = ClassicalFeatureRow(Metadata, Waveforms, Bundle)
        Code = Bundle["model"].predict(Features.to_numpy())[0]
        Row = dict(Metadata, model_path=str(ModelPath), model_name=Bundle.get("model_name", Path(ModelPath).stem),
                   prediction_code=Code, prediction_label=LabelFromMapping(Bundle.get("name_by_code", {}), Code))
        if hasattr(Bundle["model"], "predict_proba"):
            for ClassCode, Probability in zip(Bundle["class_codes"], Bundle["model"].predict_proba(Features.to_numpy())[0]):
                Row[f"probability_{LabelFromMapping(Bundle.get('name_by_code', {}), ClassCode)}"] = float(Probability)
        Rows.append(Row)
    return pd.DataFrame(Rows)


def PredictMambaRecordings(ModelPath, RecordingDirectories, LoaderArguments, RandomState=42):
    """Apply a saved Mamba checkpoint to recordings."""
    Checkpoint = Mamba.torch.load(ModelPath, map_location="cpu", weights_only=False)
    Model = Mamba.MEAMambaClassifier(**Checkpoint["model_config"])
    Model.load_state_dict(Checkpoint["state_dict"])
    Model.eval()
    Generator = np.random.default_rng(RandomState)
    Rows = []
    for Directory in RecordingDirectories:
        Waveforms, Metadata = LoadRecordingWaveforms(Directory, Generator, **LoaderArguments)
        Sequence = MambaSequence(Waveforms)
        if tuple(Sequence.shape) != tuple(Checkpoint["input_shape"]):
            raise ValueError(f"{Path(Directory).name} has Mamba input shape {Sequence.shape}, expected {tuple(Checkpoint['input_shape'])}.")
        Values = ((Sequence[np.newaxis] - Checkpoint["normalizer"]["mean"]) / Checkpoint["normalizer"]["std"]).astype(np.float32)
        with Mamba.torch.no_grad():
            Probabilities = Mamba.torch.softmax(Model(Mamba.torch.from_numpy(Values)), dim=1).numpy()[0]
        Code = Checkpoint["classes"][int(np.argmax(Probabilities))]
        Row = dict(Metadata, model_path=str(ModelPath), model_name="waveform_sequence_mamba",
                   prediction_code=Code, prediction_label=LabelFromMapping(Checkpoint.get("name_by_code", {}), Code))
        for ClassCode, Probability in zip(Checkpoint["classes"], Probabilities):
            Row[f"probability_{LabelFromMapping(Checkpoint.get('name_by_code', {}), ClassCode)}"] = float(Probability)
        Rows.append(Row)
    return pd.DataFrame(Rows)


def ProtocolFromFilename(Filename):
    """Infer the pharmacological protocol encoded in a recording filename."""
    Name = str(Filename).lower()
    if "100um4ap_50umap5" in Name:
        return "4ap_then_ap5"
    if "50umap5_100um4ap" in Name:
        return "ap5_then_4ap"
    if "100um4ap" in Name:
        return "4ap"
    if "50umap5" in Name:
        return "ap5"
    return "spontaneous"


def AsPath(path):
    """Return a Path object while accepting strings and Path-like inputs."""
    return Path(path).expanduser()


def FlattenFeature(feature):
    """Convert one feature matrix/vector to a flat 1D numpy array."""
    return np.asarray(feature).reshape(-1)


def ToDenseArray(value):
    """Convert dense or scipy sparse array-like data to a numpy array."""
    if hasattr(value, "toarray"):
        return np.asarray(value.toarray())
    return np.asarray(value)


def RequireSktimeRocket():
    """Import sktime MiniRocket classes only when ROCKET features are requested."""
    CacheDir = Path(tempfile.gettempdir()) / "numba_cache"
    os.environ.setdefault("NUMBA_CACHE_DIR", str(CacheDir))

    if MiniRocket is None or MiniRocketMultivariate is None:
        raise ImportError(
            "MiniRocket support requires sktime. Install it with `pip install sktime` "
            "or add sktime to the active environment."
        )

    return MiniRocket, MiniRocketMultivariate


def AsTimeSeriesPanel(X):
    """Convert time-series input to a sktime-compatible panel.

    Parameters
    ----------
    X : array-like
        Time-series samples. Accepted shapes are ``(samples, timepoints)`` for
        univariate waveforms, ``(samples, channels, timepoints)`` for
        multichannel signals, or a list/tuple of arrays with compatible shapes.

    Returns
    -------
    numpy.ndarray
        Dense array with shape ``(samples, channels, timepoints)``.

    Raises
    ------
    ValueError
        If ``X`` cannot be interpreted as a panel of time series.
    """
    if isinstance(X, (list, tuple)):
        X = np.stack([ToDenseArray(Item) for Item in X])
    else:
        X = ToDenseArray(X)

    if X.dtype == object and X.ndim == 1:
        X = np.stack([ToDenseArray(Item) for Item in X])

    if X.ndim == 2:
        return X[:, np.newaxis, :]
    if X.ndim == 3:
        return X
    raise ValueError("Time-series input must have shape (samples, timepoints) or (samples, channels, timepoints).")


def TSSScore(conf_matrix):
    """Compute the True Skill Statistic from a binary confusion matrix.

    Parameters
    ----------
    conf_matrix : array-like
        binary confusion matrix with shape ``(2, 2)``.

    Returns
    -------
    float
        true positive rate minus false positive rate.
    """
    conf_matrix = np.asarray(conf_matrix)
    if conf_matrix.shape != (2, 2):
        raise ValueError("tss_score expects a binary 2x2 confusion matrix.")

    Tn, Fp, Fn, Tp = conf_matrix.ravel()
    Sensitivity = Tp / (Tp + Fn) if (Tp + Fn) else 0.0
    FalsePositiveRate = Fp / (Fp + Tn) if (Fp + Tn) else 0.0
    return Sensitivity - FalsePositiveRate


def LoadFeaturePickles(file_loc, feature_column="Features"):
    """Load extracted-feature pickle files from a directory.

    Each pickle is expected to contain a pandas DataFrame with a feature column
    and one or more metadata/label columns.

    Parameters
    ----------
    file_loc : str or pathlib.Path
        directory containing ``.pkl``/``.pickle`` files.
    feature_column : str
        name of the DataFrame column containing features.

    Returns
    -------
    pandas.DataFrame
        concatenated rows with ``Source_File`` and ``Source_Row`` columns.
    """
    file_loc = AsPath(file_loc)
    Rows = []

    Paths = sorted(file_loc.glob("*.pkl")) + sorted(file_loc.glob("*.pickle"))
    for Path in Paths:
        try:
            Df = pd.read_pickle(Path)
        except Exception as Exc:
            print(f"Error loading {Path.name}: {Exc}")
            continue

        if feature_column not in Df.columns:
            print(f"Skipping {Path.name}: missing column {feature_column!r}")
            continue

        Df = Df.copy()
        Df["Source_File"] = Path.name
        Df["Source_Row"] = np.arange(Df.shape[0])
        Rows.append(Df)

    if not Rows:
        raise ValueError(f"No readable feature pickle files found in {file_loc}.")

    return pd.concat(Rows, ignore_index=True)


def BuildClassificationDataset(
    data,
    label,
    class_tags,
    pre_label=None,
    pre_tags=None,
    feature_column="Features",
    flatten=True,
):
    """Build ``X`` and ``y`` arrays from extracted features and label tags.

    Parameters
    ----------
    data : pandas.DataFrame
        feature table, for example from :func:`LoadFeaturePickles`.
    label : str
        column used as the classification target.
    class_tags : list[list[str]] or dict
        class definitions. If a list is used,
            labels are ``0..n-1``. If a dict is used, dict keys become class labels.
    pre_label : str, optional
        metadata column used to filter rows before classification.
    pre_tags : list[str], optional
        accepted values for ``pre_label``.
    feature_column : str
        column containing feature vectors or matrices.
    flatten : bool
        if True, flatten each feature entry. Set to False for
            raw time-series matrices passed to MiniRocket.

    Returns
    -------
    tuple
        ``(X, y, metadata)`` where ``X`` is a 2D feature matrix, ``y`` is a
        1D label array, and ``metadata`` stores source file/row information.
    """
    if pre_label is not None and pre_tags is not None:
        pre_tags = {str(Tag) for Tag in pre_tags}
        data = data[data[pre_label].astype(str).isin(pre_tags)]

    if isinstance(class_tags, dict):
        ClassItems = list(class_tags.items())
    else:
        ClassItems = list(enumerate(class_tags))

    Features = []
    Labels = []
    Metadata = []

    for Index, Row in data.iterrows():
        RowLabel = str(Row[label])
        MatchedClass = None

        for ClassValue, Tags in ClassItems:
            if RowLabel in {str(Tag) for Tag in Tags}:
                MatchedClass = ClassValue
                break

        if MatchedClass is None:
            continue

        Feature = Row[feature_column]
        Features.append(FlattenFeature(Feature) if flatten else np.asarray(Feature))
        Labels.append(MatchedClass)
        Metadata.append(
            {
                "Index": Index,
                "Source_File": Row.get("Source_File"),
                "Source_Row": Row.get("Source_Row"),
                "Original_Label": Row[label],
            }
        )

    if not Features:
        raise ValueError("No samples matched the requested labels/tags.")

    return np.asarray(Features), np.asarray(Labels), pd.DataFrame(Metadata)


def ExtractMiniRocketFeatures(
    X_train,
    X_test=None,
    num_kernels=10000,
    multivariate=True,
    channel_group_size=None,
):
    """Fit MiniRocket on training waveforms and transform train/test data.

    The extractor is fit only on ``X_train``. ``X_test`` is transformed with the
    fitted extractor, so test samples do not leak into the feature extraction
    stage.

    Notes
    -----
    Even when ``multivariate=False`` and the data contain a single channel, this
    wrapper uses ``MiniRocketMultivariate`` internally. This preserves the
    expected ``(samples, channels, timepoints)`` panel layout in recent sktime
    versions, where the univariate ``MiniRocket`` transformer may interpret a
    2D numpy array as one sample instead of many samples.

    Parameters
    ----------
    X_train : array-like
        Train signals with shape ``(samples, timepoints)``
            or ``(samples, channels, timepoints)``.
    X_test : array-like, optional
        Test signals with the same channel/time layout.
    num_kernels : int
        Number of MiniRocket kernels.
    multivariate : bool
        Use the multivariate MiniRocket transformer. Single-channel data are
        still handled through the multivariate transformer for layout safety.
    channel_group_size : int, optional
        If set, fit one MiniRocket extractor per channel block and concatenate
        the resulting features. This is useful for high-channel-count MEA data.

    Returns
    -------
    dict
        Dictionary with:

        - ``X_train``: transformed train feature matrix;
        - ``X_test``: transformed test feature matrix, when ``X_test`` is given;
        - ``extractors``: fitted MiniRocket extractor objects;
        - ``channel_slices``: channel blocks used for extraction.
    """
    MiniRocket, MiniRocketMultivariate = RequireSktimeRocket()
    X_train = AsTimeSeriesPanel(X_train)
    X_test = None if X_test is None else AsTimeSeriesPanel(X_test)

    if X_test is not None and X_train.shape[1:] != X_test.shape[1:]:
        raise ValueError("X_train and X_test must have the same channel/timepoint dimensions.")

    NChannels = X_train.shape[1]
    if channel_group_size is None:
        ChannelSlices = [slice(0, NChannels)]
    else:
        ChannelSlices = [
            slice(Start, min(Start + channel_group_size, NChannels))
            for Start in range(0, NChannels, channel_group_size)
        ]

    TrainFeatures = []
    TestFeatures = []
    Extractors = []

    for ChannelSlice in ChannelSlices:
        XiTrain = X_train[:, ChannelSlice, :]
        XiTest = None if X_test is None else X_test[:, ChannelSlice, :]

        if multivariate or XiTrain.shape[1] > 1:
            Extractor = MiniRocketMultivariate(num_kernels=num_kernels)
            FitTrain = XiTrain
            TransformTrain = XiTrain
            TransformTest = XiTest
        else:
            # In recent sktime versions, MiniRocket on a 2D numpy array can
            # interpret the panel as one sample. The multivariate transformer
            # preserves the expected (samples, channels, timepoints) layout,
            # even when there is only one channel.
            Extractor = MiniRocketMultivariate(num_kernels=num_kernels)
            FitTrain = XiTrain
            TransformTrain = XiTrain
            TransformTest = XiTest

        Extractor.fit(FitTrain)
        Extractors.append(Extractor)
        TrainFeatures.append(np.asarray(Extractor.transform(TransformTrain)))
        if TransformTest is not None:
            TestFeatures.append(np.asarray(Extractor.transform(TransformTest)))

    Result = {
        "X_train": np.concatenate(TrainFeatures, axis=1),
        "extractors": Extractors,
        "channel_slices": ChannelSlices,
    }
    if X_test is not None:
        Result["X_test"] = np.concatenate(TestFeatures, axis=1)

    return Result


def MiniRocketClassifierCV(
    X,
    y,
    n_splits=25,
    test_size=0.2,
    alphas=None,
    random_state=None,
    num_kernels=10000,
    multivariate=True,
    channel_group_size=None,
    scale_features=False,
    with_mean=False,
):
    """Repeated stratified classification using MiniRocket features and Ridge.

    MiniRocket is fitted separately inside each train/test split, using only the
    training samples. This keeps the test fold out of the feature-extractor fit.
    The function is suited for raw waveform/time-series inputs, not for feature
    matrices that have already been transformed.

    Parameters
    ----------
    X : array-like
        raw time-series data with shape ``(samples, timepoints)``
            or ``(samples, channels, timepoints)``.
    y : array-like
        target labels.
    n_splits : int
        number of repeated train/test splits.
    test_size : float
        fraction of samples used for testing.
    alphas : array-like, optional
        alpha grid for ``RidgeClassifierCV``.
    random_state : int, optional
        seed used to make splits reproducible.
    num_kernels : int
        number of MiniRocket kernels.
    multivariate : bool
        use the multivariate MiniRocket transformer.
    channel_group_size : int, optional
        split channels into blocks and
            concatenate per-block MiniRocket features.
    scale_features : bool
        apply ``StandardScaler`` after MiniRocket.
    with_mean : bool
        passed to ``StandardScaler`` when scaling is enabled.

    Returns
    -------
    dict
        metrics, confusion matrix, predictions, fitted models, scalers,
        and MiniRocket extractors for each fold.
    """
    X = AsTimeSeriesPanel(X)
    y = np.asarray(y)
    alphas = np.logspace(-3, 3, 10) if alphas is None else alphas
    Classes = np.unique(y)
    Average = "binary" if len(Classes) == 2 and 1 in Classes else "weighted"
    CumulativeConfusionMatrix = np.zeros((len(Classes), len(Classes)), dtype=float)
    Rng = np.random.default_rng(random_state)

    Records = []
    TrainPredictions = []
    TestPredictions = []
    TrainLabels = []
    TestLabels = []
    Models = []
    Scalers = []
    RocketExtractors = []

    for FoldIndex in range(n_splits):
        SplitSeed = None if random_state is None else int(Rng.integers(0, 2**32 - 1))
        XTrain, XTest, YTrain, YTest = train_test_split(
            X,
            y,
            shuffle=True,
            stratify=y,
            test_size=test_size,
            random_state=SplitSeed,
        )

        RocketResult = ExtractMiniRocketFeatures(
            XTrain,
            XTest,
            num_kernels=num_kernels,
            multivariate=multivariate,
            channel_group_size=channel_group_size,
        )
        XTrainFeatures = RocketResult["X_train"]
        XTestFeatures = RocketResult["X_test"]

        Scaler = None
        if scale_features:
            Scaler = StandardScaler(with_mean=with_mean)
            XTrainFeatures = Scaler.fit_transform(XTrainFeatures)
            XTestFeatures = Scaler.transform(XTestFeatures)

        Clf = SklearnRidgeClassifierCV(alphas=alphas)
        Clf.fit(XTrainFeatures, YTrain)

        TrainPred = Clf.predict(XTrainFeatures)
        TestPred = Clf.predict(XTestFeatures)
        TrainConf = confusion_matrix(YTrain, TrainPred, labels=Classes)
        TestConf = confusion_matrix(YTest, TestPred, labels=Classes)
        CumulativeConfusionMatrix += TestConf

        Record = {
            "Fold_Index": FoldIndex,
            "Train_Accuracy": accuracy_score(YTrain, TrainPred),
            "Test_Accuracy": accuracy_score(YTest, TestPred),
            "Train_Precision": precision_score(YTrain, TrainPred, average=Average, zero_division=0),
            "Test_Precision": precision_score(YTest, TestPred, average=Average, zero_division=0),
            "Train_Recall": recall_score(YTrain, TrainPred, average=Average, zero_division=0),
            "Test_Recall": recall_score(YTest, TestPred, average=Average, zero_division=0),
            "Rocket_Features": XTrainFeatures.shape[1],
        }
        if len(Classes) == 2:
            Record["Train_TSS"] = TSSScore(TrainConf)
            Record["Test_TSS"] = TSSScore(TestConf)

        Records.append(Record)
        TrainPredictions.append(TrainPred)
        TestPredictions.append(TestPred)
        TrainLabels.append(YTrain)
        TestLabels.append(YTest)
        Models.append(Clf)
        Scalers.append(Scaler)
        RocketExtractors.append(RocketResult["extractors"])

    return {
        "metrics": pd.DataFrame(Records),
        "confusion_matrix": CumulativeConfusionMatrix,
        "classes": Classes,
        "train_predictions": TrainPredictions,
        "test_predictions": TestPredictions,
        "train_labels": TrainLabels,
        "test_labels": TestLabels,
        "models": Models,
        "scalers": Scalers,
        "rocket_extractors": RocketExtractors,
    }


def RidgeClassifierCV(
    X,
    y,
    n_splits=25,
    test_size=0.2,
    alphas=None,
    random_state=None,
    with_mean=False,
):
    """Repeated stratified train/test evaluation with ``RidgeClassifierCV``.

    Parameters
    ----------
    X : array-like
        feature matrix with shape ``(n_samples, n_features)``.
    y : array-like
        target labels.
    n_splits : int
        number of repeated train/test splits.
    test_size : float
        fraction of samples used for testing.
    alphas : array-like, optional
        alpha grid for ridge cross-validation.
    random_state : int, optional
        seed used to make the repeated splits reproducible.
    with_mean : bool
        passed to :class:`sklearn.preprocessing.StandardScaler`.

    Returns
    -------
    dict
        metrics, confusion matrix, predictions, fitted models, and scalers.
    """
    X = np.asarray(X)
    y = np.asarray(y)
    alphas = np.logspace(-3, 3, 10) if alphas is None else alphas
    Classes = np.unique(y)
    Average = "binary" if len(Classes) == 2 and 1 in Classes else "weighted"
    CumulativeConfusionMatrix = np.zeros((len(Classes), len(Classes)), dtype=float)
    Rng = np.random.default_rng(random_state)

    Records = []
    TrainPredictions = []
    TestPredictions = []
    TrainLabels = []
    TestLabels = []
    Models = []
    Scalers = []

    for FoldIndex in range(n_splits):
        SplitSeed = None if random_state is None else int(Rng.integers(0, 2**32 - 1))
        XTrain, XTest, YTrain, YTest = train_test_split(
            X,
            y,
            shuffle=True,
            stratify=y,
            test_size=test_size,
            random_state=SplitSeed,
        )

        Scaler = StandardScaler(with_mean=with_mean)
        XTrain = Scaler.fit_transform(XTrain)
        XTest = Scaler.transform(XTest)

        Clf = SklearnRidgeClassifierCV(alphas=alphas)
        Clf.fit(XTrain, YTrain)

        TrainPred = Clf.predict(XTrain)
        TestPred = Clf.predict(XTest)
        TrainConf = confusion_matrix(YTrain, TrainPred, labels=Classes)
        TestConf = confusion_matrix(YTest, TestPred, labels=Classes)
        CumulativeConfusionMatrix += TestConf

        Record = {
            "Fold_Index": FoldIndex,
            "Train_Accuracy": accuracy_score(YTrain, TrainPred),
            "Test_Accuracy": accuracy_score(YTest, TestPred),
            "Train_Precision": precision_score(YTrain, TrainPred, average=Average, zero_division=0),
            "Test_Precision": precision_score(YTest, TestPred, average=Average, zero_division=0),
            "Train_Recall": recall_score(YTrain, TrainPred, average=Average, zero_division=0),
            "Test_Recall": recall_score(YTest, TestPred, average=Average, zero_division=0),
        }

        if len(Classes) == 2:
            Record["Train_TSS"] = TSSScore(TrainConf)
            Record["Test_TSS"] = TSSScore(TestConf)

        Records.append(Record)
        TrainPredictions.append(TrainPred)
        TestPredictions.append(TestPred)
        TrainLabels.append(YTrain)
        TestLabels.append(YTest)
        Models.append(Clf)
        Scalers.append(Scaler)

    return {
        "metrics": pd.DataFrame(Records),
        "confusion_matrix": CumulativeConfusionMatrix,
        "classes": Classes,
        "train_predictions": TrainPredictions,
        "test_predictions": TestPredictions,
        "train_labels": TrainLabels,
        "test_labels": TestLabels,
        "models": Models,
        "scalers": Scalers,
    }


def PlotClassificationResults(results, save_loc=None, save_name="classification", show=False):
    """Plot performance boxplots and cumulative confusion matrix.

    Parameters
    ----------
    results : dict
        Output of :func:`RidgeClassifierCV` or :func:`MiniRocketClassifierCV`.
    save_loc : str or pathlib.Path, optional
        directory where plots are saved.
    save_name : str
        filename prefix for saved plots.
    show : bool
        whether to display plots interactively.
    """
    Metrics = results["metrics"]
    save_loc = None if save_loc is None else AsPath(save_loc)
    if save_loc is not None:
        save_loc.mkdir(parents=True, exist_ok=True)

    MetricColumns = ["Accuracy", "Precision", "Recall"]
    TrainValues = [Metrics[f"Train_{Name}"] for Name in MetricColumns]
    TestValues = [Metrics[f"Test_{Name}"] for Name in MetricColumns]

    plt.figure(figsize=(12, 8))
    plt.subplot(2, 2, 1)
    plt.boxplot(TrainValues, labels=MetricColumns)
    plt.ylabel("Value")
    plt.title("Train Performance")

    plt.subplot(2, 2, 3)
    plt.boxplot(TestValues, labels=MetricColumns)
    plt.ylabel("Value")
    plt.title("Test Performance")

    if "Train_TSS" in Metrics.columns:
        plt.subplot(2, 2, 2)
        plt.boxplot(Metrics["Train_TSS"], labels=["TSS"])
        plt.ylabel("Value")
        plt.title("Train TSS")

        plt.subplot(2, 2, 4)
        plt.boxplot(Metrics["Test_TSS"], labels=["TSS"])
        plt.ylabel("Value")
        plt.title("Test TSS")

    plt.tight_layout()
    if save_loc is not None:
        plt.savefig(save_loc / f"{save_name}_performance.png")
    if show:
        plt.show()
    plt.close()

    plt.figure(figsize=(8, 6))
    sns.heatmap(
        results["confusion_matrix"],
        annot=True,
        fmt=".0f",
        cmap="Blues",
        xticklabels=results["classes"],
        yticklabels=results["classes"],
    )
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.title("Confusion Matrix")
    plt.tight_layout()
    if save_loc is not None:
        plt.savefig(save_loc / f"{save_name}_confusion_matrix.png")
    if show:
        plt.show()
    plt.close()


def Classifier(
    file_loc,
    pre_label,
    label,
    pre_tag,
    tag,
    save_loc,
    save_name,
    save_results=False,
    n_splits=25,
    test_size=0.2,
    random_state=None,
    show=False,
    use_minirocket=False,
    feature_column="Features",
    num_kernels=10000,
    multivariate=True,
    channel_group_size=None,
    scale_rocket_features=False,
):
    """Load feature pickle files and run a complete classification workflow.

    This function keeps the call style of the original repository script while
    returning structured results that can be reused downstream.
    Depending on ``use_minirocket``, the feature column is either treated as
    already extracted features or as raw waveforms/time series.

    Parameters
    ----------
    file_loc : str
        directory containing feature DataFrame pickle files.
    pre_label : str
        metadata column used for pre-filtering.
    label : str
        metadata column used as classification target.
    pre_tag : list[str]
        accepted values for ``pre_label``.
    tag : list[list[str]] or dict
        class tags used to convert labels to classes.
    save_loc : str
        directory where plots/results are saved.
    save_name : str
        filename prefix for saved artifacts.
    save_results : bool
        whether to save the fold-level results pickle.
    n_splits : int
        number of repeated train/test splits.
    test_size : float
        fraction of samples used for testing.
    random_state : int, optional
        seed for reproducible splits.
    show : bool
        whether to display plots interactively.
    use_minirocket : bool
        if True, treat ``feature_column`` as raw
            time-series data and extract MiniRocket features inside each split.
    feature_column : str
        column containing extracted features or raw signals.
    num_kernels : int
        number of MiniRocket kernels when ``use_minirocket`` is True.
    multivariate : bool
        use multivariate MiniRocket for multichannel signals.
    channel_group_size : int, optional
        split channels into blocks before
            MiniRocket extraction.
    scale_rocket_features : bool
        apply ``StandardScaler`` after MiniRocket.

    Returns
    -------
    dict
        dataset metadata, metrics, confusion matrix, models, and scalers.
    """
    Data = LoadFeaturePickles(file_loc, feature_column=feature_column)
    X, Y, Metadata = BuildClassificationDataset(
        Data,
        label=label,
        class_tags=tag,
        pre_label=pre_label,
        pre_tags=pre_tag,
        feature_column=feature_column,
        flatten=not use_minirocket,
    )
    if use_minirocket:
        Results = MiniRocketClassifierCV(
            X,
            Y,
            n_splits=n_splits,
            test_size=test_size,
            random_state=random_state,
            num_kernels=num_kernels,
            multivariate=multivariate,
            channel_group_size=channel_group_size,
            scale_features=scale_rocket_features,
        )
    else:
        Results = RidgeClassifierCV(
            X,
            Y,
            n_splits=n_splits,
            test_size=test_size,
            random_state=random_state,
        )
    Results["metadata"] = Metadata
    Results["X_shape"] = X.shape

    PlotClassificationResults(Results, save_loc=save_loc, save_name=save_name, show=show)

    if save_results:
        save_loc = AsPath(save_loc)
        save_loc.mkdir(parents=True, exist_ok=True)
        ResultsDf = Results["metrics"].copy()
        ResultsDf["Train_Predictions"] = Results["train_predictions"]
        ResultsDf["Train_Labels"] = Results["train_labels"]
        ResultsDf["Test_Predictions"] = Results["test_predictions"]
        ResultsDf["Test_Labels"] = Results["test_labels"]
        ResultsDf.to_pickle(save_loc / f"{save_name}_results.pkl")

    return Results


# Backward-compatible aliases for releases that exposed snake_case names.
tss_score = TSSScore
load_feature_pickles = LoadFeaturePickles
build_classification_dataset = BuildClassificationDataset
extract_minirocket_features = ExtractMiniRocketFeatures
minirocket_classifier_cv = MiniRocketClassifierCV
ridge_classifier_cv = RidgeClassifierCV
plot_classification_results = PlotClassificationResults
classifier = Classifier
